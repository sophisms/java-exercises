package org.generation.ecommerce.productos;

import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service //Para indicarle que es un servicio
public class ProductoService {
	public final ArrayList<Producto> lista = new ArrayList<Producto>();
	
	//Constructor
	public ProductoService() {
		lista.add(new Producto("Plum�n tinta fugaz",
				"Plum�n tinta fugaz color verde para pintarr�n", "plumonVerde.jpg", 25.0));
		lista.add(new Producto("Borrador pintarr�n",
				"Borrador para pintarr�n de tinta fugaz", "borradorB.jpg", 45.0));
		lista.add(new Producto("Cuaderno profesional cuadro chico",
				"Cuaderno profesional cuadro chico Norma", "cuaderno.jpg", 40.00));
	}
	
	public ArrayList<Producto> getProductos() {
		return lista;
	}

	public Producto getProducto(Long prodId) {
		for (Producto producto : lista) {
			if (producto.getId() == prodId)
				return producto;
		}
		return null;
	}

	public void deleteProducto(Long prodId) {
		for (Producto producto : lista) {
			if (producto.getId() == prodId) {
				lista.remove(producto);
				break;
			}
		}
	}
}
