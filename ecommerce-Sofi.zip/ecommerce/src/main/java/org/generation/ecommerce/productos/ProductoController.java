package org.generation.ecommerce.productos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping (path="/api/productos/")
public class ProductoController {
	
	private final ProductoService prodService;
	
	@Autowired //nos est� haciendo el favor de instanciar ProductoService sin tener que ponerle new ProductoService... y adem�s lo est� haciendo solo en el momento correcto
	// Cuando se ejecuta el Web Application Context, busca todos los Autowired y los corre.
	public ProductoController(ProductoService prodService) { // recibe como par�metro al servicio ya instanciado
		this.prodService = prodService;
	}// Constructor
	
	@GetMapping //est� jalando lo que est� en la url
	public List<Producto> getProductos() {
		return prodService.getProductos();
	} 
	
	@GetMapping(path="{prodId}") //est� jalando el id que ponemos en la url y la est� pasando como par�metro
	public Producto getProducto(@PathVariable("prodId") Long prodId) {
		return prodService.getProducto(prodId);
	} 
	
	@PostMapping
	public void addProducto() {
		
	}
	
	@PutMapping
	public void updateProducto() {
		
	}
	
	@DeleteMapping (path="{prodId}")
	public void deleteProducto(@PathVariable("prodId") Long prodId) {
		prodService.deleteProducto(prodId);
	}
	
}
